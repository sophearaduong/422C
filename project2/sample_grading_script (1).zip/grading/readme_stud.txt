HOW TO RUN THE GRADING SCRIPT

These are instructions for running the grading script that we will use for grading your assignment.  This is not exactly the same as the sample test cases provided earlier.

As described in the project description, make your Project2_yourEID.zip.
Place it into the submission directory.
Then run ./grade.sh .
CAUTION: your zip file will be deleted after grading, so keep a copy!
There are three other sample test cases, so that you can see behavior of the script in case of compile/runtime errors as well.
You may see brief_result.csv to see the brief results and you may see detailed_feedback to see the difference between expected output and actual output for each submission for all of the tests.
