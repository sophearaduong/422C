package assignment2;
public class Driver
{
	public static void main(String[] args)
    {
        i am compile error
	}
}
