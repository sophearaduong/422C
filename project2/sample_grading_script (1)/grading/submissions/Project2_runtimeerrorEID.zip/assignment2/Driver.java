package assignment2;
public class Driver
{
	public static void main(String[] args)
    {
        throw new RuntimeException("I am a runtime exception");
	}
}
