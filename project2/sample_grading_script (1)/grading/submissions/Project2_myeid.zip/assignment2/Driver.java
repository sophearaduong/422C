package assignment2;
public class Driver
{
	public static void main(String[] args)
    {
        System.out.println("Welcome to Mastermind.");
        System.out.println("Do you want to play a new game? (Y/N):");
        System.out.println("You have 12 guess(es) left.");
        System.out.println("Enter guess:");
        System.out.println("GGGG -> 1b_0w");
        System.out.println("You have 11 guess(es) left.");
        System.out.println("Enter guess:");
        System.out.println("GGBB -> 1b_1w");
        System.out.println("You have 10 guess(es) left.");
        System.out.println("Enter guess:");
        System.out.println("BGBB -> 2b_0w");
        System.out.println("");
        System.out.println("You have 9 guess(es) left.");
        System.out.println("Enter guess:");
        System.out.println("BGRR -> 2b_0w");
        System.out.println("");
        System.out.println("You have 8 guess(es) left.");
        System.out.println("Enter guess:");
        System.out.println("BGPP -> 3b_0w");
        System.out.println("");
        System.out.println("You have 7 guess(es) left.");
        System.out.println("Enter guess:");
        System.out.println("BGPO -> 2b_2w");
        System.out.println("");
        System.out.println("You have 6 guess(es) left.");
        System.out.println("Enter guess:");
        System.out.println("BGOP -> 4b_0w");
        System.out.println("You win!");
        System.out.println("");
        System.out.println("Do you want to play a new game? (Y/N):");
	}
}
